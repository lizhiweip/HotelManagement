package com.li.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.li.pojo.User;

/**
 * @Author lzw
 * @Date 2024/1/2 18:43
 * @description
 */
public interface UserService extends IService<User> {
}
