package com.li.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.li.pojo.RoomType;

/**
 * @Author lzw
 * @Date 2024/1/2 18:41
 * @description
 */
public interface RoomTypeService extends IService<RoomType> {
}
