package com.li.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.li.pojo.Room;
import com.li.pojo.RoomPrice;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author lzw
 * @Date 2024/1/2 18:42
 * @description
 */

public interface RoomPriceService extends IService<RoomPrice> {

}
