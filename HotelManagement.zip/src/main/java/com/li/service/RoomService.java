package com.li.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.li.pojo.Room;

/**
 * @Author lzw
 * @Date 2024/1/2 18:42
 * @description
 */
public interface RoomService extends IService<Room> {
}
