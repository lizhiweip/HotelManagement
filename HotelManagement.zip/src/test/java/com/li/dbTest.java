package com.li;

import org.junit.jupiter.api.Test;

public class dbTest {
    @Test
    void connectTest(){

    }
}
